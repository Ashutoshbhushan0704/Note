import React from "react";

function header(){
  return (
  <header>
    <h1>Keeper</h1>
  </header>
  );
}
export default header;