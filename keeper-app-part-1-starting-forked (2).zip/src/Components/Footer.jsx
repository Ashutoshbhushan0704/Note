import React from "react";


function footer(){
const currentTime = new Date().getFullYear;
return (
  <footer>
<p>Copyright @ {currentTime}</p>
  </footer>
);
}
export default footer;
